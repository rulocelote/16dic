package com.miempresa.a16dic

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.ActionBar
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    lateinit var toolbar: ActionBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = supportActionBar!!

        setNav(navigationView as BottomNavigationView)
    }

    fun setNav(navigationBar: BottomNavigationView) {


        navigationBar.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_songs -> {
                    toolbar.title = "Songs"
                    val songsFragment = SongsFragment.newInstance()
                    openFragment(songsFragment)

                }
                R.id.navigation_albums -> {
                    toolbar.title = "Albums"
                    val albumsFragment = AlbumsFragment.newInstance()
                    openFragment(albumsFragment)

                }
                R.id.navigation_artists -> {
                    toolbar.title = "Artists"
                    val artistsFragment = ArtistsFragment.newInstance()
                    openFragment(artistsFragment)

                }
            }
            false
        }

    }



    private fun openFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.container, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }
}